<?php  
	$bdd = new PDO('mysql:host=127.0.0.1; dbname=gestiondetransport', 'root', '');
	//echo "La connexion a ete etablie !!!";
?>