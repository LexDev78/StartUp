<?php  
	require '../connecter.php';

	extract($_POST);

	if (isset($valider)) {
		$ajouterClient = $bdd->prepare('INSERT INTO clients (nomClient,prenomClient,villeClient,adresseClient,genreClient,telephoneClient) VALUES (?,?,?,?,?,?)');

		$ajouterClient->execute(array($nomClient,$prenomClient,$villeClient,$adresseClient,$genreClient,$telephoneClient));

		$message = 'Cet client a ete ajouter avec succes :)';
	}
?>