<?php  
	require '../actions/clientActionAjouter.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title></title>
	</head>
	<body>
		<h2><a href="afficherClients.php">Afficher les clients</a></h2>

		<form method="POST">
			<label>Nom du client</label><br>
			<input type="text" name="nomClient" required><br>

			<label>Prenom du client</label><br>
			<input type="text" name="prenomClient" required><br>

			<label>Ville du client</label><br>
			<input type="text" name="villeClient" required><br>

			<label>Adresse du client</label><br>
			<input type="text" name="adresseClient" required><br>

			<label>Genre du client</label><br>
			<select name="genreClient" required>
				<option required></option>
				<option value="M">Homme</option>
				<option value="F">Femme</option>
			</select><br>

			<label>Telephone du client</label><br>
			<input type="text" name="telephoneClient" required><br><br>

			
			<input type="submit" name="valider">
		</form>
		<?php  
			if (isset($message)) {
				echo '<b style="color: green;">'.$message.'</b>';
			}
		?>
	</body>
</html>