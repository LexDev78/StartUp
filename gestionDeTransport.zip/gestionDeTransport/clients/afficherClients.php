<?php  
	require '../actions/clientActionAfficher';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title></title>
	</head>
	<body>
		<h2><a href="ajouterClients.php">Ajouter un nouveau client</a>a</h2>

		<table>
			<tr>
				<td>N°</td>
				<td>Nom du client</td>
				<td>Prenom du client</td>
				<td>Ville du client</td>
				<td>Adresse du client</td>
				<td>Genre du client</td>
				<td>Telephone du client</td>
			</tr>
			<?php foreach ($resultat as $donnees) { ?>
			<tr>
				<td><?= $donnees['idClient']; ?></td>
				<td><?= $donnees['nomClient']; ?></td>
				<td><?= $donnees['prenomClient']; ?></td>
				<td><?= $donnees['villeClient']; ?></td>
				<td><?= $donnees['adresseClient']; ?></td>
				<td><?= $donnees['genreClient']; ?></td>
				<td><?= $donnees['telephoneClient']; ?></td>
				<td><a href="modifierClients.php?id=<?= $donnees['idClient']; ?>">Modifier le client</a></td>
				<td><a href="supprimerClients.php?id=<?= $donnees['idClient']; ?>">Supprimer le client</a></td>
			</tr>
			<?php } ?>
		</table>
	</body>
</html>