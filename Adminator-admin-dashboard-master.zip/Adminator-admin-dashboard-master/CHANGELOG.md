### Changelog

#### 1.0.0

- Intial release

#### 1.1.0

- Upgrade to webpack 5

#### 2.0.0

- Upgrade to Bootstrap 5