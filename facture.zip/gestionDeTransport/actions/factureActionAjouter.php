<?php  
	require '../connecter.php';
	
	htmlspecialchars(extract($_GET));

	if (isset($valider)) {
		echo 'numero : ' .$numero. ' Date : ' .$date. ' client : ' .$client.'<br/>';

		foreach ($designation as $designations) {
			echo ' Designation : ' .$designations;
		}

		echo "<br/>";

		foreach ($quantite as $quantites) {
			echo ' Quantite : ' .$quantites ;
		}

		echo "<br/>";

		foreach ($prix as $price) {
			echo ' Prix : ' .$price;
		}

		echo "<br/>";

		foreach ($montant as $montants) {
			echo ' Montant : ' .$montants;
		}
	}
