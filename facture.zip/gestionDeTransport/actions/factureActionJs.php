<script>
    function produit() {
        var id = this.getAttribute("id");
        var numero = id.substring(id.length-1, id.length);
        var quantite1 = document.getElementById("quantite"+numero).value;
        var prix1 = document.getElementById("prix"+numero).value;
        var montant1 = document.getElementById("montant"+numero);
        var produit = parseInt(quantite1) * parseInt(prix1);
        if (!isNaN(produit)) montant1.value = produit;
        var montantTotal = 0;
        montants = document.getElementsByClassName("montant");
        for (var i=0;i<montants.length;i++){
            if (!isNaN(parseInt(montants[i].value))) montantTotal = montantTotal + parseInt(montants[i].value);
        }
        var montantHT = document.getElementById("montantHT");
        montantHT.value = montantTotal;
        var tva = document.getElementById("tva");
        tva.value = montantTotal * 18/100;
        var montantTTC = document.getElementById("TotalTTC");
        montantTTC.value = montantTotal+montantTotal*18/100;
    }
    var elements = document.getElementsByClassName("element");
    for (var i=0;i<elements.length;i++){
        elements[i].addEventListener("change", produit, false);
        elements[i].addEventListener("change", produit, false);
    }
</script>