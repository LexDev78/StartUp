<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
    <h1>Clique sur ce lien pour <a href="factures/ajouterFacture.php">Voir la Facture</a></h1>
</body>
</html>