<?php  
require '../actions/factureActionAjouter.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factures</title>
</head>
<body>
    <form action="" methode="GET">
        <div>
            <label for="numero">Numero</label>
            <input type="text" name="numero" id="numero">

            <label for="date">Date</label>
            <input type="date" name="date" id="date">

            <label for="client">Client</label>
            <select name="client" id="client">
                <option value="">-- --</option>
                <option value="sory">Sory</option>
                <option value="madou">Madou</option>
                <option value="aissata">Aissata</option>
                <option value="ibrim">Ibrim</option>
            </select>
        </div>
        <div>
            <table border="1">
                <tr style="text-align: center;">
                    <td>Designation</td>
                    <td>Quantite</td>
                    <td>Prix</td>
                    <td>Montant</td>
                </tr>
                <tr>
                    <td><input type="text" name="designation[]" id="designation1"></td>
                    <td><input type="text" name="quantite[]" id="quantite1" class="element"></td>
                    <td><input type="text" name="prix[]" id="prix1" class="element"></td>
                    <td><input type="text" name="montant[]" id="montant1" class="montant"></td>
                </tr>
                <tr>
                    <td><input type="text" name="designation[]" id="designation2"></td>
                    <td><input type="text" name="quantite[]" id="quantite2" class="element"></td>
                    <td><input type="text" name="prix[]" id="prix2" class="element"></td>
                    <td><input type="text" name="montant[]" id="montant2" class="montant"></td>
                </tr>
                <tr>
                    <td><input type="text" name="designation[]" id="designation3"></td>
                    <td><input type="text" name="quantite[]" id="quantite3" class="element"></td>
                    <td><input type="text" name="prix[]" id="prix3" class="element"></td>
                    <td><input type="text" name="montant[]" id="montant3" class="montant"></td>
                </tr>
                <tr>
                    <td>MontantHT</td>
                    <td></td>
                    <td></td>
                    <td><input type="text" name="montantHT" id="montantHT"></td>
                </tr>
                <tr>
                    <td>TVA</td>
                    <td></td>
                    <td></td>
                    <td><input type="text" name="tva" id="tva"></td>
                </tr>
                <tr>
                    <td>TotalTTC</td>
                    <td></td>
                    <td></td>
                    <td><input type="text" name="TotalTTC" id="TotalTTC"></td>
                </tr>
            </table>
        </div>
        <div>
            <button name="valider">Envoyer</button>
        </div>
    </form>
</body>
</html>
<?php  
require '../actions/factureActionJs.php';
?>